import phase.pyphase as phase
from pypylon import pylon, genicam

def listDevices() -> list:
    """Gets a list of available cameras. Returns a list of CameraDeviceInfo objects."""
    camera_info_list = []
    # camera_info_list.append(
    #     CameraDeviceInfo(
    #         "0815-0000",
    #         "0815-0001",
    #         "virtual_camera",
    #         CameraDeviceType.DEVICE_TYPE_GENERIC_PYLON,
    #         CameraInterfaceType.INTERFACE_TYPE_VIRTUAL
    #     )
    # )
    camera_info_list.append(
        phase.stereocamera.CameraDeviceInfo(
            "0815-0000",
            "0815-0001",
            "virtual_images",
            phase.stereocamera.CameraDeviceType.DEVICE_TYPE_GENERIC_PYLON,
            phase.stereocamera.CameraInterfaceType.INTERFACE_TYPE_VIRTUAL
        )
    )
    # camera_info_list.append(
    #     CameraDeviceInfo(
    #         "0815-0000",
    #         "0815-0001",
    #         "virtual_tools",
    #         CameraDeviceType.DEVICE_TYPE_GENERIC_PYLON,
    #         CameraInterfaceType.INTERFACE_TYPE_VIRTUAL
    #     )
    # )
    try:
        # Get the transport layer factory.
        tlFactory = pylon.TlFactory.GetInstance()

        # Get all attached devices
        # exit application if no device is found.
        devices = tlFactory.EnumerateDevices()
        if len(devices) < 2:
            return camera_info_list

        long_prefixes = ["I3DRTitania", "I3DRPhobos"]
        short_prefixes = ["746974616e", "70686f626f"]
        prefix_device_types = [
            phase.stereocamera.DEVICE_TYPE_TITANIA,
            phase.stereocamera.CameraDeviceType.DEVICE_TYPE_PHOBOS
        ]

        # Create and attach Pylon Devices.
        for device in devices:
            # Identify I3DR devices with prefix
            camera_defined_id = device.GetUserDefinedName()
            is_i3dr_device = False
            device_type = None
            zip_data = zip(
                long_prefixes, short_prefixes, prefix_device_types
            )
            for long_prefix, short_prefix, i3dr_device_type in zip_data:
                found_long = long_prefix in camera_defined_id
                found_short = short_prefix in camera_defined_id
                if found_short or found_long:
                    is_short_prefix = found_short and not found_long
                    is_i3dr_device = True
                    device_type = i3dr_device_type
                    break

            if is_i3dr_device:
                # Get camera serials from user defined name
                if is_short_prefix:
                    # expects 16 character identier
                    # 15 character unique serial followed by 'l' or 'r'
                    camera_i3dr_serial = camera_defined_id[0:15]
                    camera_lr = camera_defined_id[-1]
                    device_serial = device.GetSerialNumber()
                    device_class = device.GetDeviceClass()
                if not is_short_prefix:
                    # expects format 'I3DRXXXX_XXXXXXXX_x'
                    camera_defined_id_array = camera_defined_id.split("_")
                    if len(camera_defined_id_array) != 3:
                        err_msg = "Invalid device user id name format: " \
                            + camera_defined_id + " Expected the format: \
                            'I3DRXXXX_XXXXXXXX_x'"
                        raise Exception(err_msg)
                    camera_i3dr_serial = camera_defined_id_array[1]
                    camera_lr = camera_defined_id_array[2]
                    device_serial = device.GetSerialNumber()
                    device_class = device.GetDeviceClass()
                # check if other camera already exists in the list
                # with that i3dr serial
                # (e.g. the left camera of the same device)
                found_in_camera_list = False
                camera_list_found_index = None
                for i, camera_info in enumerate(camera_info_list):
                    if camera_info.getUniqueSerial() == camera_i3dr_serial:
                        found_in_camera_list = True
                        camera_list_found_index = i

                left_serial = ""
                right_serial = ""
                if camera_lr == "l":
                    left_serial = device_serial
                if camera_lr == "r":
                    right_serial = device_serial
                if device_class == "BaslerUsb":
                    interface_type = \
                        phase.stereocamera.CameraInterfaceType.INTERFACE_TYPE_USB
                elif device_class == "BaslerGigE":
                    interface_type = \
                        phase.stereocamera.CameraInterfaceType.INTERFACE_TYPE_GIGE
                else:
                    raise Exception(
                        "Unsupported camera class: " + device_class)

                # add camera to list
                if found_in_camera_list:
                    # update already existing
                    # stereo camera device info in list
                    if camera_lr == "l":
                        camera_info_list[camera_list_found_index].\
                            setLeftCameraSerial(device_serial)
                    if camera_lr == "r":
                        camera_info_list[camera_list_found_index].\
                            setRightCameraSerial(device_serial)
                if not found_in_camera_list:
                    # append new stereo camera device info to list
                    camera_info_list.append(
                        phase.stereocamera.CameraDeviceInfo(
                            left_serial, right_serial, camera_i3dr_serial,
                            device_type, interface_type
                        )
                    )

    except genicam.GenericException as e:
        # Error handling
        print("An exception occurred when getting camera serials.", e)
        return None

    return camera_info_list
